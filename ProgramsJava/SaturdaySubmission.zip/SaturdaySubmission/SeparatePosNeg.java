package SaturdaySubmission;

import java.util.Arrays;
import java.util.Scanner;

class Solution{

    public void sortPosNeg(int[]arr)
    {
        int left=0,right=arr.length-1;
        for(int i=0;i<arr.length;i++)
        {
            if(arr[i]>0)
            {
                left++;
            }
            else if(arr[i]<0)
            {
                right--;
            }
            if(left<right)
            {
                int temp = arr[left];
                arr[left] = arr[right];
                arr[right] = temp;
            }
        }
    }
}
public class SeparatePosNeg {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Size of Array:- ");
        int size =  sc.nextInt();
        int arr[] = new int[size];
        for(int i = 0;i<size;i++)
        {
            System.out.println("Enter the Element:- "+i);
            arr[i] = sc.nextInt();
        }
        System.out.println("USER INPUT ARRAY:-"+ Arrays.toString(arr));
        Solution s1 = new Solution();
        s1.sortPosNeg(arr);
        for(int i = 0;i<arr.length;i++)
        {
            System.out.print(arr[i]+" ");
        }
        sc.close();
    }
}
